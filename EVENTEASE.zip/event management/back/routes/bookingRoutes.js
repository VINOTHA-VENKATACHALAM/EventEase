// routes/bookingRoutes.js
const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const authenticate = require('../middleware/authenticate');

// Save Booking
router.post('/bookings', authenticate, async (req, res) => {
    const { eventName, eventDate, eventPlace, additionalOptions } = req.body;

    if (!eventName || !eventDate || !eventPlace) {
        return res.status(400).json({ error: 'Missing required fields for booking.' });
    }

    try {
        const booking = new Booking({
            userId: req.userId, // Use the authenticated user's ID
            eventName,
            eventDate,
            eventPlace,
            additionalOptions,
        });

        await booking.save();
        res.status(201).json({ message: 'Booking saved successfully!' });
    } catch (error) {
        console.error('Error saving booking:', error);
        res.status(500).json({ error: 'Failed to save booking. Please try again later.' });
    }
});

module.exports = router;
