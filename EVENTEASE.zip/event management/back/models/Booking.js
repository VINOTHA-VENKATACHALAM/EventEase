// models/Booking.js
const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    eventName: { type: String, required: true },
    eventDate: { type: Date, required: true },
    eventPlace: { type: String, required: true },
    additionalOptions: { type: String },
});

module.exports = mongoose.model('Booking', bookingSchema);
