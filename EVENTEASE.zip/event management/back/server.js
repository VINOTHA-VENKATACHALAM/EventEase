const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
const PORT = 5000;
const JWT_SECRET = 'your_jwt_secret'; // Use a strong secret in production

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect('mongodb+srv://sduml:sduml@product.mdqfz.mongodb.net/', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB'))
.catch((err) => console.error('MongoDB connection error:', err));

// Define Mongoose schemas
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

const bookingSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  eventName: { type: String, required: true },
  eventDate: { type: Date, required: true },
  eventPlace: { type: String, required: true },
  additionalOptions: { type: String },
});

// Define Mongoose models
const User = mongoose.model('User', userSchema);
const Booking = mongoose.model('Booking', bookingSchema);

// JWT Authentication middleware
const authenticate = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1]; // Extract token from the Authorization header
  if (!token) return res.status(401).json({ message: 'Access Denied' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.id; // Assign the user ID from the token to the request
    console.log('Authenticated user ID:', req.userId); // Log user ID for debugging
    next();
  } catch (error) {
    res.status(400).json({ message: 'Invalid Token or Token Expired' });
  }
};

// Register User
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    const user = new User({ username, password: hashedPassword });
    await user.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    res.status(500).json({ error: 'User registration failed. Please try again later.' });
  }
});

// Login User
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ error: 'User not found' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ error: 'Invalid password' });

    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
  } catch (error) {
    res.status(500).json({ error: 'Login failed. Please try again later.' });
  }
});

// Save Booking
app.post('/api/bookings', authenticate, async (req, res) => {
  const { eventName, eventDate, eventPlace, additionalOptions } = req.body;

  if (!eventName || !eventDate || !eventPlace) {
    return res.status(400).json({ error: 'Missing required fields for booking.' });
  }

  try {
    const booking = new Booking({
      userId: req.userId, // Use the authenticated user's ID
      eventName,
      eventDate,
      eventPlace,
      additionalOptions,
    });

    await booking.save();
    res.status(201).json({ message: 'Booking saved successfully!' });
  } catch (error) {
    console.error('Error saving booking:', error);
    res.status(500).json({ error: 'Failed to save booking. Please try again later.' });
  }
});

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Set up a route to serve the home page (default page)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Set up a route for the booking page, protected by JWT authentication
app.get('/booking', authenticate, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'booking.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});


